alert('iOS!');

$.index.open();


